const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BlWYUv5Z.js","assets/index-BQDul_Gz.js","assets/index-CW-BE3wJ.css"])))=>i.map(i=>d[i]);
import{i as p,_ as r}from"./index-BQDul_Gz.js";const _=p("App",{web:()=>r(()=>import("./web-BlWYUv5Z.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
