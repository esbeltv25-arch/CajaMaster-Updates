const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DbYh3NCH.js","assets/index-CV1OMj8g.js","assets/index-CW-BE3wJ.css"])))=>i.map(i=>d[i]);
import{a as p,_ as r}from"./index-CV1OMj8g.js";const _=p("App",{web:()=>r(()=>import("./web-DbYh3NCH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
