const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C3KEhWhC.js","assets/index-B3Ck9kis.js","assets/index-B67VboZO.css"])))=>i.map(i=>d[i]);
import{a as p,_ as r}from"./index-B3Ck9kis.js";const _=p("App",{web:()=>r(()=>import("./web-C3KEhWhC.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
